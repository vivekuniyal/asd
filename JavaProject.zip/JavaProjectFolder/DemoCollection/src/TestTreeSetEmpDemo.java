import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TestTreeSetEmpDemo {

	public static void main(String[] args) {
		TreeSet<Employee> empList=new TreeSet<Employee>();
		Employee emp1=new Employee(112233, "Sunil", 12365, "IT","Scheme A");
		Employee emp2=new Employee(112236, "Anil", 123605, "Sales","Scheme W");
		Employee emp3=new Employee(152238, "Sunny", 123635, "HR","Scheme S");
		Employee emp4=new Employee(112233, "Sunil", 12365, "IT","Scheme A");
		Employee emp5=new Employee(112221, "Ram", 12385, "Marketing","Scheme C");
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp4);
		empList.add(emp5);
		
		
		Iterator<Employee> it=empList.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}

	}

}
