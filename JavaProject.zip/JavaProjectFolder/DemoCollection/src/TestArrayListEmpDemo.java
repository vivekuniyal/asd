import java.util.ArrayList;
import java.util.Iterator;

public class TestArrayListEmpDemo {

	public static void main(String []args)
	{
		ArrayList<Employee> empList=new ArrayList<Employee>();
		Employee emp1=new Employee(112233, "Sunil", 12365.20, "IT","Scheme A");
		Employee emp2=new Employee(112236, "Anil", 123605.20, "Sales","Scheme W");
		Employee emp3=new Employee(112238, "Sunny", 123635.20, "HR","Scheme S");
		Employee emp4=new Employee(112239, "Surjit", 123656.20, "IT","Scheme D");
		Employee emp5=new Employee(112239, "Surjit", 123656.20, "IT","Scheme D");

		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp4);
		empList.add(emp5);
		Iterator<Employee> it=empList.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
		
	}
}
