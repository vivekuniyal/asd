import java.sql.*;

public class TestEmpSelectDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(
					"jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","Lab1btrg21","lab1boracle");
			
			
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from emp_157754");
			
			System.out.println("-----------Result Set Metadata----------");
			ResultSetMetaData rsmd=rs.getMetaData();
			int colCount=rsmd.getColumnCount();
			System.out.println("No. of columns "+colCount);
			for(int i=1;i<=colCount;i++)
			{
				System.out.println("Column name :" 
			+rsmd.getColumnName(i) + " | Column Type :" +rsmd.getColumnTypeName(i));
				
				
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			while(rs.next())
			System.out.println(" : " +rs.getInt("emp_id")+
					" : " +rs.getString("emp_name")+
					" : " +rs.getFloat("emp_salary"));
			
			
			con.close();
			
			
			
		} catch (ClassNotFoundException |SQLException e) {
			
			e.printStackTrace();
		}
	}

}
