import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpInsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee id :");
		int empId=sc.nextInt();
		System.out.println("Enter employee name :");
		String empNmae=sc.next();
		System.out.println("Enter employee salary :");
		int empSal=sc.nextInt();
		
		String query="insert into emp_157754 values(?,?,?)";
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(
					"jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","Lab1btrg21","lab1boracle");
			
			PreparedStatement pst=con.prepareStatement(query);
			pst.setInt(1,empId);
			pst.setString(2,empNmae);
			pst.setInt(3,empSal);
			
			int data=pst.executeUpdate();
			if(data!=0)
			System.out.println("Data Inserted successfully" + data);
			
		}
		catch (ClassNotFoundException |SQLException e) {
			
			e.printStackTrace();
		}
	}

}
