package com.cg.mps.dao;

import java.util.ArrayList;

import com.cg.mps.dto.*;
import com.cg.mps.exception.MobileException;

public interface MobileDao {
	int purchaseMobile(PurchaseDetails purchaseDetail) throws MobileException;
	ArrayList<Mobiles> allMobiles() throws MobileException;
	int deleteMobileDetail(int mobId) throws MobileException;
	ArrayList<Mobiles> searchMobile(int minPrice,int maxPrice) throws MobileException;
	int quantityMobile(int mobileId) throws MobileException;
}
