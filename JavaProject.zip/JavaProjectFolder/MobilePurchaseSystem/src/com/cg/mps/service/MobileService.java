package com.cg.mps.service;

import java.util.ArrayList;

import com.cg.mps.dto.Mobiles;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.MobileException;

public interface MobileService {
	int purchaseMobile(PurchaseDetails purchaseDetail) throws MobileException;
	ArrayList<Mobiles> allMobiles() throws MobileException;
	int deleteMobileDetail(int mobId) throws MobileException;
	ArrayList<Mobiles> searchMobile(int minPrice,int maxPrice) throws MobileException;
	boolean validateEmpName(String cName) throws MobileException;
	boolean validateMobileNo(String phoneNo) throws MobileException;
	boolean validateEmailId(String emailId) throws MobileException;
	boolean validateMobileId(int mobileId) throws MobileException;
}
