package com.capgemini.client;

import java.util.Scanner;

public class First {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the total no. of products :");
		int total=sc.nextInt();
		
		String productNames[]=new String[total];
		for(int i=0;i<total;i++)
		{
			System.out.println("Enter product name : ");
			productNames[i]=sc.next();
		}
		String temp=null;
		
		
		for(int i=0;i<productNames.length;i++)
		{
			for(int j=i+1;j<productNames.length;j++)
			{
				
				if(productNames[i].compareTo(productNames[j])>=0)
				{
					temp=productNames[i];
					productNames[i]=productNames[j];
					productNames[j]=temp;
				}
			}
	
		}
		
		for(String name:productNames)
		{
			System.out.println(name);
		}
		

	}

}
