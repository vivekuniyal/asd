package com.capgemini.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Second {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the total no. of products :");
		int total=sc.nextInt();

		ArrayList<String> productNames=new ArrayList<String>();
		for(int i=0;i<total;i++)
		{
			System.out.println("Enter product name : ");
			productNames.add(sc.next());
		}
		String temp=null;
		
		
		Collections.sort(productNames);
		
		for(String name:productNames)
		{
			System.out.println(name);
		}
	}


}