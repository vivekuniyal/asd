package com.capgemini.junitdemo;

import org.junit.*;

public class PersonMainCheck {
	static Person2 person=null;
	@BeforeClass
	public static void setUp()
	{
		person=new Person2();
		person.setFirstName("Ram");
		person.setLastName("Thakur");
		person.setGender('M');
		System.out.println("Object created for testing....");
	}
	@AfterClass
	public static void breakDown()
	{
		System.out.println("All testing done...");
	}
	@Test
	public void testFirstName()
	{
		Assert.assertEquals("Ram", person.getFirstName());
		System.out.println("getFirstName method successfully tested.");
	}
	@Test
	public void testLastName()
	{
		Assert.assertEquals("Thakur", person.getLastName());
		System.out.println("getLastName method successfully tested.");
	}
	@Test
	public void testGender()
	{
		Assert.assertEquals('M', person.getGender());
		System.out.println("getGender method successfully tested.");
	}
	@Test
	public void testDisplay()
	{
		System.out.println("Display tested successfully.");
	}
}
