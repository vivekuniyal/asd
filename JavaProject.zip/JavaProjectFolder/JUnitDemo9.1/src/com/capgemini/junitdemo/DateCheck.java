package com.capgemini.junitdemo;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import junit.framework.Assert;


public class DateCheck {
	static Date date=null;
	@BeforeClass
	public static void setUp()
	{
		date=new Date();
		date.setDay(20);
		date.setMonth(8);
		date.setYear(2018);
		
		System.out.println("Date created Successfully");
		
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("All testing done");
	}
	@Test
	public void testDay()
	{
		Assert.assertEquals(20,date.getDay());
	}
	@Test
	public void testMonth()
	{
		Assert.assertEquals(8,date.getMonth());
	}
	@Test
	public void testYear()
	{
		Assert.assertEquals(2018,date.getYear());
	}
	
	
}
