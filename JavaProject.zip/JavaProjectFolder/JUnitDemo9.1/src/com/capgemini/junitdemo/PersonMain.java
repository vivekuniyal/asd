package com.capgemini.junitdemo;

class Person2{
	private String firstName;
	private String lastName;
	private char gender;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public Person2(String firstName, String lastName, char gender) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	Person2()
	{
		
	}
	
	void display()
	{
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println();
		System.out.println("First Name : "+firstName);
		System.out.println("Last Name : "+lastName);
		System.out.println("Gender : "+gender);
	}
}
public class PersonMain {

	public static void main(String[] args) {
		Person2 person=new Person2("Divya", "Bharathi",'F');
		person.display();
		

	}

}
