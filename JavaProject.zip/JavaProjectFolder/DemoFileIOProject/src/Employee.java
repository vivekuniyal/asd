import java.io.Serializable;

public class Employee implements Serializable{

	int empId;
	String empName;
	float empSalary;
	
	public Employee() {
	}

	public Employee(int empId, String empName, float empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "Employee [empId is " + empId + ", empName is " + empName + ", empSalary is " + empSalary + "]";
	}
	
	
}
