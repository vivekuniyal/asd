import java.io.FileInputStream;
import java.io.*;

public class TestEmployeeDeserialDemo {

	public static void main(String[] args) {
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try {
			fis=new FileInputStream("EmployeeObj.obj");
			ois=new ObjectInputStream(fis);
			Employee ee=(Employee)ois.readObject();
			
			System.out.println("Employee info from file : "+ee);
			 ee=(Employee)ois.readObject();
			System.out.println("Employee info from file : "+ee);
			
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
