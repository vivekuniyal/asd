import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestEmployeeReadDemo {

	public static void main(String[] args) {
		
		try {
			InputStreamReader isr=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(isr);
			System.out.println("Enter employee Id");
			int eid=Integer.parseInt(br.readLine());
			System.out.println("Enter Employee Name");
			String ename=br.readLine();
			
			System.out.println("Enter employee Salary");
			float esalary=Float.parseFloat(br.readLine());
			
			
			System.out.println(eid+" : " +ename +" :" +esalary);
			
			} 
		catch (IOException e) {
			e.printStackTrace();
			}
		
		

	}

}
