import java.io.FileNotFoundException;
import java.util.Properties;
import java.io.*;

public class TestPropsWriteDemo {

	public static void main(String[] args) {
		FileOutputStream fos=null;
		Properties myDBInfo=null;
		try {
			fos=new FileOutputStream("dbInfo.properties");
			myDBInfo=new Properties();
			myDBInfo.setProperty("dbUser", "System");
			myDBInfo.setProperty("dbPassword", "Root");
			myDBInfo.store(fos, "This is Database Information");
			System.out.println("Data is written Successfully");
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
