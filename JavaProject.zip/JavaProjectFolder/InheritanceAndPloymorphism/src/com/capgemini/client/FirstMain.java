package com.capgemini.client;

import com.capgemini.bean.Account;
import com.capgemini.bean.Person;

public class FirstMain {

	public static void main(String[] args) {
		
		Person smith=new Person("Smith",20);
		Person kathy=new Person("Kathy", 25);
		Account smithAccount=new Account();
		smithAccount.setAccHolder(smith);
		smithAccount.setBalance(2000);
		
		Account kathyAccount=new Account(3000,kathy);
		
		System.out.println("Smith Account balance is "+smithAccount.getBalance());
		System.out.println("Kathy Account balance is "+kathyAccount.getBalance());
		
		smithAccount.deposit(2000);
		kathyAccount.withdraw(2000);
		System.out.println("After Transaction");
		
		System.out.println("Smith Account balance is "+smithAccount.getBalance());
		System.out.println("Kathy Account balance is "+kathyAccount.getBalance());
		
		
		System.out.println(smithAccount.getAccNum());
		System.out.println(kathyAccount.getAccNum());
		
	}

}
