
public class VarArgsDemo {
public int add(int ...a)
{
	int sum=0;
	for(int element:a)
	{
		sum=sum+element;
	}
	return sum;
}
	public static void main(String[] args) {
		VarArgsDemo ob1=new VarArgsDemo();
		System.out.println(ob1.add());
		System.out.println(ob1.add(10,20,30,15,12,15,2));
	}

}
