package com.capgemini.assignment;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Third {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		fos=new FileOutputStream("EmployeeInfo.obj");
		oos=new ObjectOutputStream(fos);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the No. of employees :");
		int number=sc.nextInt();
		for(int i=0;i<number;i++) {
		System.out.println("Enter Emp id");
		int eid=sc.nextInt();
		System.out.println("Enter Emp Name");
		String ename=sc.next();
		System.out.println("Enter Emp Salary");
		float esal=sc.nextFloat();
		System.out.println("Enter Designation");
		String edesi=sc.next();
		System.out.println("Enter Insurance Scheme");
		String eins=sc.next();
		
		Employee employee=new Employee(eid, ename, esal, edesi, eins);
		writeInFile(oos,employee);
		}
		System.out.println("All employees added successfully");
		System.out.println("__________________________________");
		System.out.println("All employees are");
		
		FileInputStream fis=new FileInputStream("D://157754 Vivek Uniyal//JavaProjectFolder//FileIO8.1//EmployeeInfo.obj");
		ObjectInputStream ois=new ObjectInputStream(fis);
		for(int i=0;i<number;i++)
		{
			Employee emp=(Employee)ois.readObject();
			System.out.println(emp);
		}

	}
	
	static void writeInFile(ObjectOutputStream oos, Employee employee) throws IOException
	{
		oos.writeObject(employee);
		System.out.println("Success");
	}

}
