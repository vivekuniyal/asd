package com.capgemini.exception;

public class EmployeeException extends Exception{
	private double salary;
	public EmployeeException(Double a) {
	salary = a; }
	
	public String toString() {
	return salary+" is below 3000";
	}
}
