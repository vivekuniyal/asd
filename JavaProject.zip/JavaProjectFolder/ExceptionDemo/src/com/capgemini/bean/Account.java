package com.capgemini.bean;

public class Account {
	 private long accNum;
	 private double balance;
	 Person accHolder;
	 
	public void deposit(double amount) {
		 balance=balance+amount;
	 }
	 public void withdraw(double amount) {
		 if(balance>=amount)
			 balance=balance-amount;
		 else
			 System.out.println("Insufficient Balance");
	 }
	 public double getBalance()
	 {
		 return balance;
	 }
	public Account(long accNum, double balance, Person accHolder) {
		
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	 
	 
}
