package com.capgemini.client;

import com.capgemini.client.FirstNameException;
import com.capgemini.client.LastNameException;
import com.capgemini.client.Person;

class Person{
	private String firstName;
	private String lastName;
	private char gender;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public Person(String firstName, String lastName, char gender) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	Person()
	{
		firstName = "";
		lastName = "";
		gender = 'M';
	}
}
class FirstNameException extends Exception
{	
	public FirstNameException() {
		
	}
	
	public String toString() {
		return "No First Name";
		}
	
}
class LastNameException extends Exception
{	
	public LastNameException() {
		// TODO Auto-generated constructor stub
	}
	
	public String toString() {
		return "No Last Name";
		}
	
}

public class First {
	
	public static void check(Person person) throws FirstNameException,LastNameException
	{
		if(person.getFirstName().equals(""))
			throw new FirstNameException();
		else if(person.getLastName().equals(""))
			throw new LastNameException();
		else
			System.out.println("No exceptions");
	}
	public static void main(String args[])
	{
	 
	 Person person=new Person();
	 person.setFirstName("Ram");
	 person.setLastName("ASD");
	 person.setGender('M');
	 try {
		check(person);
	} catch (FirstNameException e) {
	System.out.println(e);
	
	} catch (LastNameException e) {
		
		System.out.println(e);
	}
	 Person person2=new Person();
	 person2.setFirstName("");
	 person2.setLastName("");
	 person2.setGender('F');
	 
	 try {
		check(person2);
	} catch (FirstNameException | LastNameException e) {
	
		System.out.println(e);
	}
	 finally
	 {
		 System.out.println("Rest of code");
	 }
	 
	}
	
}
