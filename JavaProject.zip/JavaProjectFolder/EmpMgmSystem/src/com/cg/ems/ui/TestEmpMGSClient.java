package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class TestEmpMGSClient {
	static EmployeeService empService=null;
	static Scanner sc=null;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sc=new Scanner(System.in);
		int choice;
		empService =new EmployeeServiceImpl();
		System.out.println("------------------WELCOME TO EMS------------------");
		while(true)
		{
			System.out.println("What do yo want to do??");
			System.out.println("1: Add Employee");
			System.out.println("2: Show all Employee");
			System.out.println("3: Update Employee");
			System.out.println("4: Delete Employee");
			System.out.println("5: Exit");
			System.out.println("Enter your choice :");
			choice =sc.nextInt();
			switch(choice)
			{
			case 1: insertDetails();break;
			case 2: showDetails();break;
			case 3: updateDetails();break;
			case 4: deleteEmployee();break;
			case 5:System.exit(0);
			default:System.out.println("Invalid input");
			}
		}
		
	}
	private static void showDetails() {
		ArrayList<Employee> empList;
		try {
			empList = empService.getAllEmployee();
		
		System.out.println("\t EmpId \t EmpName \t EmpSalary");
		for(Employee employee:empList)
		{
			System.out.println("\t"+employee.getEmpId()+"\t"
					+employee.getEmpName()+"\t"+employee.getEmpSal());
		}
		
		
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
		
		
	}
	private static void updateDetails() {
		// TODO Auto-generated method stub
		
	}
	private static void deleteEmployee() {
		// TODO Auto-generated method stub
		
	}
	private static void insertDetails() {
		// TODO Auto-generated method stub
		try {
		System.out.println("Enter employee ID :");
		int empId=sc.nextInt();
		
		System.out.println("Enter employee Name :");
		String empName=sc.next();
		if(empService.validateEmpName(empName))
		{
		System.out.println("Enter employee Salary :");
		float empSal=sc.nextFloat();
			Employee employee=new Employee(empId, empName, empSal);
			System.out.println("Please wait");
			int flag=empService.addEmployee(employee);
			if(flag==1) {
				System.out.println("Employee Details successfully inserted");
			showDetails();
			}
			else
				System.out.println("Problem with insertion");
		}
		}
		catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	

}
