package com.cg.ems.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDao empDao=null;
	 public EmployeeServiceImpl() {
	empDao=new EmployeeDaoImpl();	
	}
	
	
	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		
		return empDao.getAllEmployee();
	}

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.addEmployee(employee);
	}

	@Override
	public boolean validateEmpName(String eName) throws EmployeeException {
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, eName))
			return true;
		else
			throw new EmployeeException("Invalid Employee name. "
					+ "Should start with capital"
					+ " Only characters are allowed");
		
	//	return false;
	}
	

}
