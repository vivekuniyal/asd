package com.cg.ems.dao;
import java.util.ArrayList;
import com.cg.ems.dto.*;
import com.cg.ems.exception.EmployeeException;
public interface EmployeeDao {
	public ArrayList<Employee> getAllEmployee() throws EmployeeException;
	public int addEmployee(Employee employee) throws EmployeeException;
	
}
