package com.cg.ems.dao;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{
	Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	ArrayList<Employee> empList=null;
	public EmployeeDaoImpl() {
		daoLogger=Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException  {
		try {
			con=DBUtil.getConn();
			
			String selectQuery="select * from emp_157754";
			st=con.createStatement();
			rs=st.executeQuery(selectQuery);
			
			empList=new ArrayList<Employee>();
			while(rs.next())
			{
				empList.add(new Employee(rs.getInt(1),rs.getString(2),rs.getFloat(3)));
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
			try {
				st.close();
				rs.close();
				con.close();
			} catch (SQLException e) {
				daoLogger.error(e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		daoLogger.info("All Data Received :"+empList);
		return empList;
	}

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		try {
			con=DBUtil.getConn();
			String query="insert into emp_157754 values(?,?,?)";
			
			PreparedStatement pst=con.prepareStatement(query);
			pst.setInt(1,employee.getEmpId());
			pst.setString(2,employee.getEmpName());
			pst.setFloat(3,employee.getEmpSal());
			return pst.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EmployeeException(e.getMessage());
		}
	}

}
