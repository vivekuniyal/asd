package com.capgemini.assignment;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class First {

	public static void main(String[] args) {
		FileOutputStream fos=null;
		Properties personProsInfo=null;
		Scanner sc=new Scanner(System.in);
		FileInputStream fis=null;
		
		try {
			fos=new FileOutputStream("PersonProps.properties");
			personProsInfo=new Properties();
			System.out.println("Enter no. of persons");
			int num=sc.nextInt();
			for(int i=1;i<=num;i++) 
			{
				
			System.out.println("----------Enter Person's Details here--------- ");
			System.out.println("Enter Name :");
			String name=sc.next();
			System.out.println("Enter Age :");
			String age=sc.next();
			System.out.println("Enter gender :");
			String gender=sc.next();
			
			personProsInfo.setProperty("Name",name);
			personProsInfo.setProperty("Age", age);
			personProsInfo.setProperty("Gender", gender);
			personProsInfo.store(fos, "Entry of "+" person");
			System.out.println("Data is written Successfully");
			}
			//personProsInfo.store(fos, "Entry of "+" person");
		fis=new FileInputStream("D://157754 Vivek Uniyal//JavaProjectFolder//PropertyFileAndJDBC10.1//PersonProps.properties");	
			Properties personDetailsFromFile=new Properties();
			System.out.println(personDetailsFromFile);
			System.out.println("######################");
			System.out.println("From PersonProps file");
			
			personDetailsFromFile.load(fis);
			for(int i=0;i<num;i++) {
				
			String name=personDetailsFromFile.getProperty("Name");	
			String age=personDetailsFromFile.getProperty("Age");
			String gender=personDetailsFromFile.getProperty("Gender"
					);
			System.out.println(name+ ":"+age+" : "+gender);
			
			
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}


	}

}
