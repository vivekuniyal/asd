package com.capgemini.fundamentals;

import java.util.Scanner;

class Person3{
	private String firstName;
	private String lastName;
	private char gender;
	private long mobileNum;
	Scanner sc=new Scanner(System.in);
	
	
	void inputMobileNumber()
	{
	System.out.println("Enter Mobile No. :");
	mobileNum=sc.nextLong();
	}
	void inputDetails()
	{
		System.out.println("Enter first name :");
		firstName=sc.next();
		System.out.println("Enter Last Name :");
		lastName=sc.next();
		System.out.println("Enter Gender :");
		gender=sc.next().charAt(0);
	}

	

	void display()
	{
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println();
		System.out.println("First Name : "+firstName);
		System.out.println("Last Name : "+lastName);
		System.out.println("Gender : "+gender);
		System.out.println("Mobile Number : "+mobileNum);
	}
	
	
	
}



public class Fourth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person3 person=new Person3();
		person.inputDetails();
		person.inputMobileNumber();
		person.display();

	}

}
