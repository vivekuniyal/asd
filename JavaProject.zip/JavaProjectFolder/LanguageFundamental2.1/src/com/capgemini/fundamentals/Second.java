package com.capgemini.fundamentals;

public class Second {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=Integer.parseInt(args[0]);
		if(num>0)
			System.out.println("Positive Number");
		else if(num<0)
			System.out.println("Negative Number");
		else
			System.out.println("Number is Zero");
			
	}

}
