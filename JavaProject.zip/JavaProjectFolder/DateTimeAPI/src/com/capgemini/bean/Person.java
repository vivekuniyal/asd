package com.capgemini.bean;

import java.time.LocalDate;
import java.time.Period;

public class Person{
	private String firstName;
	private String lastName;
	private char gender;
	private LocalDate dateOfBirth;
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public Person(String firstName, String lastName, char gender, LocalDate dateOfBirth) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
	}
	public Person()
	{
		
	}
	
	
}
