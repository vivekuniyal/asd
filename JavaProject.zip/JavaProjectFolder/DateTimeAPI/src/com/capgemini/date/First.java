package com.capgemini.date;

import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class First {

	public static void main(String[] args) {
		LocalDate date=inputDate();
		
		
		LocalDate start = LocalDate.now();
		
		Period period = start.until(date);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
		

	}

	private static LocalDate inputDate() {
		LocalDate enteredDate = null;
		try{
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter date in dd/MM/yyyy format:");
			String input  = scanner.nextLine();
			enteredDate = LocalDate.parse(input,formatter);
			System.out.println("Entered Date:"+ enteredDate);
			scanner.close();
			}
			catch(Exception e)
			{
				System.out.println("Please enter the date in mentioned format only...");
				
			}
		return enteredDate;
			
	}

}
