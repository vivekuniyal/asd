package com.capgemini.date;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.capgemini.bean.*;
public class Fifth {

	static Period calculateAge(LocalDate dateOfBirth)
	{
		
		return dateOfBirth.until(LocalDate.now());
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person=new Person();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first name:");
		String firstName=sc.nextLine();
		System.out.println("Enter last name:");
		String lastName=sc.nextLine();
		System.out.println("Enter gender (M/F):");
		char gender=sc.nextLine().charAt(0);
		person.setFirstName(firstName);
		person.setLastName(lastName);
		person.setGender(gender);
		person.setDateOfBirth(inputDate());
		Period age=calculateAge(person.getDateOfBirth());
		String fullName=fullNameOfPerson(person.getFirstName(),person.getLastName());
		System.out.println("Age of "+fullName +" is " 
				+ age.getYears() + " Years "+ age.getMonths() +" months "
				+ age.getDays()+" days");
		
	}

	private static String fullNameOfPerson(String firstName, String lastName) {
		
		return firstName+" "+lastName;
	}
	private static LocalDate inputDate() {
		LocalDate enteredDate = null;
		try{
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter date of birth in dd/MM/yyyy format:");
			String input  = scanner.nextLine();
			enteredDate = LocalDate.parse(input,formatter);
			
			scanner.close();
			}
			catch(Exception e)
			{
				System.out.println("Please enter the date in mentioned format only...");
				
			}
		return enteredDate;
			
	}

}
