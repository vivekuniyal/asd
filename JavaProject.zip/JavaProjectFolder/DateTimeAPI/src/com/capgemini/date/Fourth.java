package com.capgemini.date;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class Fourth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ZonedDateTime currentTime = ZonedDateTime.now();
		
		System.out.println("Enter Zone ID :");
		
		Scanner sc=new Scanner(System.in);
		String zoneId=sc.nextLine();
		ZonedDateTime currentTimeInGivenZoneId = currentTime.withZoneSameInstant(ZoneId.of(zoneId));
		System.out.println("India:"+ currentTime);
		System.out.println("In the given Zone Id:"+ currentTimeInGivenZoneId);
		

	}

}
