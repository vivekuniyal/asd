package com.capgemini.string;

import java.util.Scanner;

public class First {
	static Scanner sc=new Scanner(System.in);
	static String inputString()
	{
		System.out.println("Enter the string :");
		
		String input=sc.nextLine();
		return input;
	}
	static void showMenu()
	{
		System.out.println("1. Add the string to itself");
		System.out.println("2. Replace odd positions with #");
		System.out.println("3. Remove duplicate characters in the String");
		System.out.println("4. Change odd characters to upper case");
		System.out.println("5. Exit");
	}
	static String add(String input)
	{
		
		return input.concat(input);
	}
	static String replace(String input)
	{
		char[] chars = input.toCharArray();
		for(int i=0;i<chars.length;i++)
		{
			if(i%2==1)
				chars[i]='#';
		}
		
		
		return new String(chars);
	}
	static String removeDuplicate(String input)
	{
		char[] chars = input.toCharArray();
		int[] frequency=new int[26];
		char[] output=new char[chars.length];
		for(int i=0;i<chars.length;i++)
		{
			frequency[chars[i]-'a']++;
		}
		int k=0;
		for(int i=0;i<chars.length;i++)
		{
			if(frequency[chars[i]-'a']>=1)
			{
				
				frequency[chars[i]-'a']=0;
				output[k]=chars[i];
				k++;
			}
		}
	
		return new String(output);
		
	}
	static String upperCase(String input)
	{
		char[] chars = input.toCharArray();
		for(int i=0;i<chars.length;i++)
		{
			if(i%2==1)
				chars[i]=(char)(chars[i]-32);
		}
		
		
		
		return new String(chars);
	}
	
	public static void main(String[] args) {
		String input=inputString();
		while(true) {
		showMenu();
		System.out.println("Enter Choice :");
		int ch=sc.nextInt();
		switch(ch)
			{
		case 1:System.out.println(add(input));break;
		case 2:System.out.println(replace(input)); break;
		case 3:System.out.println(removeDuplicate(input));break;
		case 4:System.out.println(upperCase(input));break;
		case 5:System.exit(0);
		default: System.out.println("Enter a valid input");
		
			}
		
		}
		
	}

}
