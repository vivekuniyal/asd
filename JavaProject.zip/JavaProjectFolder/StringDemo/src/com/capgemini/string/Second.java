package com.capgemini.string;

import java.util.Scanner;

public class Second {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String input=sc.next();
		boolean flag=true;
		for(int i=0;i<input.length()-1;i++)
		{
			if(input.charAt(i)>input.charAt(i+1))
			{
				flag=false;
				break;
			}
		}
		if(flag==false)
			System.out.println("Entered Sring is not positive");
		else
			System.out.println("Entered string is positive");

	}

}
